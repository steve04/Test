﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FirstDataPayment;
using System.Xml;

namespace Demo
{
    /// <summary>
    /// PaymentRequest 的摘要说明
    /// </summary>
    public class PaymentRequest : IHttpHandler
    {
        HttpContext _content;
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/xml";
            _content = context;
            IFirstDataPayment payment = new FirstDataPay();
            string apikey = GetFromNameStr("apikey");
            string apiSecret = GetFromNameStr("secret");
            string payeezyToken = GetFromNameStr("payeezyToken");
            string token = GetFromNameStr("token");
            string nonce = GetFromNameStr("nonce");
            string timestamp =GetFromNameStr("timestamp");

            string tokentype = GetFromNameStr("tokentype");
            string payLoad = string.Empty;
            if (tokentype.Trim().ToLower() != "payeezy".ToLower())
            {
                TransactionRequest request = GetTranasctionRequest();
                payLoad = Newtonsoft.Json.JsonConvert.SerializeObject(request);
            }
            else {
                TokenRequest request = GetTokenRequest();
                payLoad = Newtonsoft.Json.JsonConvert.SerializeObject(request);
                token = payeezyToken;
            }
            //RequestParameters param = GetRequestParam();
            //var response = payment.PurchaseTransaction(param);

            string result = payment.SendRequest(apikey, apiSecret, payLoad, token, nonce, timestamp);
            XmlDocument doc = Newtonsoft.Json.JsonConvert.DeserializeXmlNode(result, "Response");
            context.Response.Write(doc.InnerXml);
        }


        public TransactionRequest GetTranasctionRequest() 
        {
            TransactionRequest request = new TransactionRequest();
            request.amount = GetFromNameStr("amount");
            request.currency_code = "USD";
            request.method = "credit_card";
            request.transaction_type = GetFromNameStr("transaction_type");
            request.credit_card = new Card();
            request.credit_card.cvv = GetFromNameStr("cvv_code");
            request.credit_card.exp_date = GetFromNameStr("exp_month") + GetFromNameStr("exp_year");
            request.credit_card.cardholder_name = GetFromNameStr("cardholder_name");
            request.credit_card.type = GetFromNameStr("card_type");
            request.credit_card.card_number = GetFromNameStr("cc_number");
            return request;
        }

        public TokenRequest GetTokenRequest() 
        {
            TokenRequest request = new TokenRequest();
            request.amount = GetFromNameStr("amount");
            request.currency_code = "USD";
            request.method = "token";
            request.transaction_type = GetFromNameStr("transaction_type");
            request.merchant_ref = "Astonishing-Sale";
            request.token = new Token();
            request.token.token_type = "payeezy";
            request.token.token_data = new Token_data();
            //request.token.token_data.type = GetFromNameStr("card_type");
            request.token.token_data.value = GetFromNameStr("payeezyToken");
            //request.token.token_data.cardholder_name = GetFromNameStr("cardholder_name");
            //request.token.token_data.exp_date = GetFromNameStr("exp_month") + GetFromNameStr("exp_year");
            return request;
        }

        public RequestParameters GetRequestParam() 
        {
            RequestParameters reqeustParam = new RequestParameters();
            reqeustParam.ApiKey = GetFromNameStr("apikey");
            reqeustParam.ApiSecret = GetFromNameStr("secret");
            string payeezyToken = GetFromNameStr("payeezyToken");
            string token = GetFromNameStr("token");
            reqeustParam.Nonce = GetFromNameStr("nonce");
            reqeustParam.Timestamp = GetFromNameStr("timestamp");
            TransactionRequest request = GetTranasctionRequest();
            string payLoad = Newtonsoft.Json.JsonConvert.SerializeObject(request);
            reqeustParam.Payload = payLoad;
            reqeustParam.Token = token;

            return reqeustParam;
        }


        private string GetFromNameStr(string key) 
        {
            if (_content == null) return string.Empty;
            if (_content.Request.Form[key] == null)
                return string.Empty;
            return _content.Request.Form[key].ToString();
        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}