﻿/// <reference path="jquery-1.8.3.min.js" />
/// <reference path="payeezy.js" />

//var MyApi = {
//    APIKey: "prmKHU0JmNZ9GGLfJB6vHG3suvDFDkYK", //"QKeFeza2AqAfksAF8zkVAER1MeURD0DT"//"y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a", //"j8mtmWR4qCIQIGjjqYr2NuymH12JlLwN ",
//    APISecret: "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7",
//    Token: "",
//    MercId: "b4f18fb17c535a2e",
//    PayUrl:"https://api-cert.payeezy.com/v1/transactions"
//}

var Api = {
    key:"",
    Secret:"",
    MercId:"",
    Token:"",
    PayeezyToken:""
}

$(function () {

    $('#payment_info_form').submit(function (e) {
        var $form = $(this);
        var nonce = Math.random() * 1000000000000000000;
        var timestamp = new Date().getTime();
        //Api.Token = token;
        //token = "f715a98132f57c63";

        Api.Token = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";

        //-------------------Please Eric to check {

        //Below are APIKey, MerchantIdentifier and APISceret from our sandbox account
        //If using it, will get 403 error.
        Api.key = "prmKHU0JmNZ9GGLfJB6vHG3suvDFDkYK";
        Api.Secret = "2b19c8370de247cc7b202a8ef120fd69d8367cebc0c3d08c218df4460a8aeee4";

        //Below are APIKey, MerchantIdentifier and APISceret from your help web page
        //If using it, always works.
//        Api.key = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
//        Api.Secret = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";


        //-------------------Please Eric to check }

        //Api.Secret = "2b19c8370de247cc7b202a8ef120fd69d8367cebc0c3d08c218df4460a8aeee4";
        //Api.Secret = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
        $form.attr("action", "Handler/PaymentRequest.ashx");
        $form.attr("method", "post");
        $form.append($('<input type="hidden" name="token"/>').val(Api.Token));
        $form.append($('<input type="hidden" name="payeezyToken"/>').val(Api.PayeezyToken));
        $form.append($('<input type="hidden" name="nonce"/>').val(nonce));
        $form.append($('<input type="hidden" name="timestamp"/>').val(timestamp));
        $form.append($('<input type="hidden" name="secret"/>').val(Api.Secret));
        $form.append($('<input type="hidden" name="apikey"/>').val(Api.key));
        //$form.get(0).submit();
    });

    $("#btnGetToken").click(function () {
        var apikey = $("#txtApikey").val();
        var MercId = $("#txtMercId").val();
        var Secret = $("#txtSecret").val();

        Api.key = apikey;
        Api.Secret = Secret;
        Api.MercId = MercId;
        Api.Token = $("#txtToken").val();

        //        Payeezy.setApiKey("y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a");
        //        Payeezy.setMerchantIdentifier("y6pzAbc3Def123");

        //Payeezy.setApiKey("j8mtmWR4qCIQIGjjqYr2NuymH12JlLwN");
        //Payeezy.setMerchantIdentifier("b4f18fb17c535a2e"); //b4f18fb17c535a2e//f715a98132f57c63
        //9c5d31c720fafc9527a0e8d23577755a8153395942305ef4a3415709f1f52358 

        //-------------------Please Eric to check {

        //Below are APIKey, MerchantIdentifier and APISceret from our sandbox account
        //If using it, will get 403 error.
        Payeezy.setApiKey("prmKHU0JmNZ9GGLfJB6vHG3suvDFDkYK");
        Payeezy.setMerchantIdentifier("f1d935ee59d18aec");

        //Below are APIKey, MerchantIdentifier and APISceret from your help web page
        //If using it, always works.
//        Payeezy.setApiKey("y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a");
//        Payeezy.setMerchantIdentifier("y6pzAbc3Def123");

        //-------------------Please Eric to check }


        Payeezy.createToken(responseHandler);
    });

    $("#slTokenType").change(function () {
        if ($(this).val() == "transarmor") {
            $("#trApikey").hide();
            $("#trMercId").hide();
            $("#trToken").show();
        } else {
            $("#trApikey").show();
            $("#trMercId").show();
            $("#trToken").hide();
        }
    });


})


function responseHandler(status, response) {
    var $form = $('#payment_info_form');
    if (status != 201) {
        if (response.error) {
            var errorMessages = response.error.messages;
            var allErrors = '';
            for (i = 0; i < errorMessages.length; i++) {
                allErrors = allErrors + errorMessages[i].description;
            }
            $form.find('.payment-errors').text("status:" + status + ", " + allErrors);
        }
        $form.find('button').prop('disabled', false);
    } else {
        var payeezyToken = response.token.value;
        var nonce = Math.random() * 1000000000000000000;
        var timestamp = new Date().getTime();
        //Api.Token = token;
        //token = "f715a98132f57c63";
        //var apikey = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
        //token = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
        Api.PayeezyToken = payeezyToken;
        //$form.find('.payment-errors').text("success,Payeezy:" + Api.PayeezyToken);
        $form.find('.payment-errors').text("get payeezy token success");
    }
}