﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    public interface IFirstDataPayment
    {
        string SendRequest(string apiKey, string apiSecret, string payload, string token, string nonce, string timestamp);
        TransactionResponse PurchaseTransaction(RequestParameters trans);
        TransactionResponse AuthorizeTransaction(RequestParameters trans);
        TransactionResponse CaptureTransaction(TransactionRequest trans);
        TransactionResponse RefundTransaction(TransactionRequest trans);
        TransactionResponse VoidTransaction(TransactionRequest trans);
    }
}
