﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Globalization;

namespace FirstDataPayment
{
    public class ProcessPEM
    {
        public string ReadPem(string pemPath)
        {
            string result = string.Empty;
            StreamReader sr = new StreamReader(pemPath);
            result = sr.ReadToEnd();
            if (!string.IsNullOrEmpty(result))
            {
                result = result.Replace("-----BEGIN CERTIFICATE REQUEST-----", "");
                result = result.Replace("-----END CERTIFICATE REQUEST-----", "");
            }
            byte[] privatekey = Convert.FromBase64String(result);
            return result;
        }
        internal static byte[] TrimLeadingZero(byte[] values)
        {
            byte[] r = null;
            if ((0x00 == values[0]) && (values.Length > 1))
            {
                r = new byte[values.Length - 1];
                Array.Copy(values, 1, r, 0, values.Length - 1);
            }
            else
            {
                r = new byte[values.Length];
                Array.Copy(values, r, values.Length);
            }

            return r;
        }

    }
}
