﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace FirstDataPayment
{
    public class FirstDataPay : IFirstDataPayment
    {
        private const string url = "https://api-cert.payeezy.com/v1/transactions";
        private const String NONCE = "nonce";
        private const String APIKEY = "apikey";
        private const String APISECRET = "pzsecret";
        private const String TOKEN = "token";
        private const String TIMESTAMP = "timestamp";
        private const String AUTHORIZE = "Authorization";
        private const String PAYLOAD = "payload";
        private const String OVERRIDE = "override";
        private const String MercToken = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";

        public string SendRequest(string apiKey, string apiSecret, string payload, string token, string nonce, string timestamp)
        {
                string result = string.Empty;
                var webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.Method = "POST";
                webRequest.ContentLength = payload.Length;
                webRequest.ContentType = "application/json";
                InitHeaders(webRequest.Headers, apiKey, apiSecret, payload, token, nonce, timestamp);

                StreamWriter myWriter = null;
                using (myWriter = new StreamWriter(webRequest.GetRequestStream()))
                {
                    myWriter.Write(payload);
                }

                //string pemurl = @"F:\Merchant-cert.pem";
                //System.Security.Cryptography.X509Certificates.X509Certificate Certificate = new System.Security.Cryptography.X509Certificates.X509Certificate(certurl);
                //X509Certificate Certificate = X509Certificate.CreateFromCertFile(certurl);
                //webRequest.ClientCertificates.Add(System.Security.Cryptography.X509Certificates.X509Certificate.CreateFromCertFile(certurl));


                try
                {
                    var response = (HttpWebResponse)webRequest.GetResponse();
                    using (StreamReader responseStream = new StreamReader(response.GetResponseStream()))
                    {
                        result = responseStream.ReadToEnd();
                        responseStream.Close();
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return result;
        }

        private TransactionResponse PrimaryTransaction(RequestParameters requestParam) 
        {
            string result = string.Empty;
            var webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Method = "POST";
            webRequest.ContentLength = requestParam.Payload.Length;
            webRequest.ContentType = "application/json";
            InitHeaders(webRequest.Headers, requestParam.ApiKey, requestParam.ApiSecret, requestParam.Payload, requestParam.Token, requestParam.Nonce, requestParam.Timestamp);

            StreamWriter myWriter = null;
            using (myWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                myWriter.Write(requestParam.Payload);
            }

            var response = (HttpWebResponse)webRequest.GetResponse();
            using (StreamReader responseStream = new StreamReader(response.GetResponseStream()))
            {
                result = responseStream.ReadToEnd();
                responseStream.Close();
            }
            return (TransactionResponse)Newtonsoft.Json.JsonConvert.DeserializeObject(result, new TransactionResponse().GetType());
        }

        public TransactionResponse PurchaseTransaction(RequestParameters requestParam) 
        {
            return PrimaryTransaction(requestParam);
        }

        public TransactionResponse AuthorizeTransaction(RequestParameters requestParam) 
        {
            return PrimaryTransaction(requestParam);
        }

        public TransactionResponse CaptureTransaction(TransactionRequest trans) 
        {
            return null;
        }

        public TransactionResponse RefundTransaction(TransactionRequest trans) 
        {
            return null;
        }

        public TransactionResponse VoidTransaction(TransactionRequest trans) 
        {
            return null;
        }

        private TransactionResponse SecondaryTransaction(TransactionRequest trans) 
        {
            return null;
        }

        private void InitHeaders(WebHeaderCollection quest, string apiKey, string apiSecret, string payload, string token, string nonce, string timestamp)
        {
            Dictionary<string, string> map = GetSecurityKeys(apiKey, apiSecret, payload, token, nonce, timestamp);
            foreach (var item in map)
            {
                if (PAYLOAD.Equals(item.Key))
                    continue;
                else if (NONCE.Equals(item.Key))
                    continue;
                else if (TIMESTAMP.Equals(item.Key))
                    continue;
                else if (APISECRET.Equals(item.Key))
                    continue;
                quest.Add(item.Key, item.Value);
            }
        }

        private Dictionary<string, string> GetSecurityKeys(string apiKey, string apiSecret, string payload, string token, string nonce, string timestamp)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            try
            {
                map.Add(NONCE, nonce);
                map.Add(APIKEY, apiKey);
                map.Add(TIMESTAMP, timestamp);
                map.Add(TOKEN, MercToken);
                map.Add(APISECRET, apiSecret);
                map.Add(PAYLOAD, payload);
                map.Add(AUTHORIZE, GetHMAC(map));
                return map;
            }
            catch (Exception ex)
            {
                return null;
                throw new Exception(ex.ToString());
            }
        }

        protected string GetHMAC(Dictionary<string, string> map)
        {
            //return "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
            HMAC mac = HMAC.Create("HMACSHA256");
            mac.Key = Encoding.UTF8.GetBytes(map[APISECRET]);
            StringBuilder buff = new StringBuilder();
            buff.Append(map[APIKEY]);
            buff.Append(map[NONCE]);
            buff.Append(map[TIMESTAMP]);
            if (!string.IsNullOrEmpty(map[TOKEN]))
                buff.Append(map[TOKEN]);
            if (!string.IsNullOrEmpty(map[PAYLOAD]))
                buff.Append(map[PAYLOAD]);

            byte[] macHash = mac.ComputeHash(Encoding.UTF8.GetBytes(buff.ToString()));
            String authorizeString = Convert.ToBase64String(macHash);
            return authorizeString;
        }
    }
}
