﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    [Serializable]
    public class Card
    {
        public String type { get; set; }
        public String cardholder_name { get; set; }
        public String card_number { get; set; }
        public String exp_date { get; set; }
        public String cvv { get; set; }
    }
}
