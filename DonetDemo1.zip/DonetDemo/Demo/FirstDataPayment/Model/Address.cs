﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    [Serializable]
    public class Address
    {
        public String name { get; set; }
        public String street { get; set; }
        public String state_province { get; set; }
        public String city { get; set; }
        public String country { get; set; }
        public String email { get; set; }
        public Phone phone { get; set; }
        public String zip_postal_code { get; set; }
    }
}
