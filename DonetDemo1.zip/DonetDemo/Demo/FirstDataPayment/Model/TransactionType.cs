﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    [Serializable]
    public enum TransactionType
    {
        PURCHASE,
        AUTHORIZE,
        CAPTURE,
        REFUND,
        VOID     
    }
}
