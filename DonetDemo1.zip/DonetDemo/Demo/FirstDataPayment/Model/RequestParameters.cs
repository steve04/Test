﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    [Serializable]
    public class RequestParameters
    {
        public string ApiKey { get; set; }
        public string ApiSecret { get; set; }
        public string Payload { get; set; }
        public string Token { get; set; }
        public string Nonce { get; set; }
        public string Timestamp { get; set; }
    }
}
