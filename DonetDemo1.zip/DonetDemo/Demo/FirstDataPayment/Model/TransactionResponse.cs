﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    [Serializable]
    public class TransactionResponse
    {
        public String transaction_status { get; set; }
        public String validation_status { get; set; }
        public String transaction_type { get; set; }
        public String transaction_id { get; set; }
        public String transaction_tag { get; set; }
        public String method { get; set; }
        public String amount { get; set; }
        public String currency { get; set; }
        public String avs { get; set; }
        public String cvv2 { get; set; }
        public String transarmor_token { get; set; }
        public Card card { get; set; }
        public Token token { get; set; }
        public Error Error { get; set; }
        public String correlation_id { get; set; }
        public String bank_resp_code { get; set; }
        public String bank_message { get; set; }
        public String gateway_resp_code { get; set; }
        public String gateway_message { get; set; }
    }
}
