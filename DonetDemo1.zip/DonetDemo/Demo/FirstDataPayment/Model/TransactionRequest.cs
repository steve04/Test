﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    [Serializable]
    public class TransactionRequest 
    {
        //public String id { get; set; }
        public String merchant_ref { get; set; }
        public String transaction_type { get; set; }
        public String method { get; set; }
        public String amount { get; set; }
        public String currency_code { get; set; }
        //public String transactionTag { get; set; }
        public Card credit_card { get; set; }
        //public Address billing_address { get; set; }
        //public SoftDescriptor soft_descriptors { get; set; }

        //public ThreeDomainSecureToken ThreeDomainSecureToken { get; set; }//ThreeDomainSecureToken threeDomainSecureToken
    }
}
