﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    [Serializable]
    public class TokenRequest 
    {
        public string merchant_ref { get; set; }
        public string transaction_type { get; set; }
        public string method { get; set; }
        public string amount { get; set; }
        public string currency_code { get; set; }
        public Token token { get; set; }
    }

    [Serializable]
    public class Token 
    {
        public string token_type { get; set; }
        public Token_data token_data { get; set; }
    }
    [Serializable]
    public class Token_data 
    {
        //public string type { get; set; }
        //public string cardholder_name { get; set; }
        //public string exp_date { get; set; }
        public string value { get; set; }
    }

    public enum TokenType 
    {
        payeezy,
        transarmor
    }
}
