﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    [Serializable]
    public class Phone
    {
        public string type { get; set; }
        public string number { get; set; }
    }
}
