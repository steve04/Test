﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    [Serializable]
    public class Error
    {
        private List<String> messages { get; set; }
    }
}
